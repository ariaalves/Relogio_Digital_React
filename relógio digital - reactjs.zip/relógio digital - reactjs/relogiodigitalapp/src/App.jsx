import Clock from './Clock';

function app(){
  return(
    <div className="app">
      <Clock/>
    </div>
  )
}

export default app;